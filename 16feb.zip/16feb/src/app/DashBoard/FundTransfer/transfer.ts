export class Transfer {
    constructor(public accountnumber?: number,
                public accountnumber1?: number,
                public amount?: number,
               
                ) {

        }
}
