export class AccountStatememt{
    constructor(public acc_name? :string,
        public acc_no? :number,
        public transcation? :number
    ){}
}