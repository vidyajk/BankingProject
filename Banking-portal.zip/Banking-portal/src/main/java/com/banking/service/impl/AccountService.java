package com.banking.service.impl;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.banking.entity.Account;
import com.banking.entity.BankTransfer;
import com.banking.entity.Customer;
import com.banking.entity.Transaction;

@Service
public class AccountService {

	
	
		
	}
	

		
		
	

